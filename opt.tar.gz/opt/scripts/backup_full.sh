#!/bin/bash

# Función help
help_backup() {
echo "-------------------------------------------------------------------------"
echo "USO: $0 [OPCIONES] ORIGEN DESTINO" 
echo
echo "ARGUMENTOS:"
echo "ORIGEN: DIRECTORIO AL CUAL SE LE VA A REALIZAR EL BACKUP"
echo "DESTINO: DIRECTORIO EN DONDE SE GUARDARÁ EL BACKUP"
echo
echo "OPCIONES:"
echo "-help	MUESTRA ESTE MENÚ"
echo
echo "-------------------------------------------------------------------------"
}

# Para llamar al menú de ayuda
if [ "$1" == "-help" ]; then
	help_backup
	exit 0
fi

# Validar que se pasen 2 argumentos
if [ "$#" -ne 2 ]; then
	echo "ERROR: CANTIDAD DE ARGUMENTOS INCORRECTA."
	echo "USAR -help PARA MÁS INFORMACIÓN."
	exit 1
fi

ORIGEN=$1
DESTINO=$2

# Valida la existencia del directorio de origen
if [ ! -d "$ORIGEN" ]; then
	echo "ERROR: EL DIRECTORIO DE ORIGEN ($ORIGEN) NO EXISTE."
	exit 1
fi

# Valida la existencia del directorio del destino
if [ ! -d "$DESTINO" ]; then
	echo "ERROR: EL DIRECTORIO DE DESTINO ($DESTINO) NO EXISTE."
	exit 1
fi

# Crear formato para el nombre: BASE_bkp_yyyymmdd.tar.gz
NOMBRE_BASE=$(basename $ORIGEN)
FECHA=$(date +%Y%m%d)
NOMBRE_FINAL="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

echo "INICIANDO BACKUP DE $ORIGEN..."

# Comprime el archivo del origen y lo guarda en el nombre final dentro de la carpeta destino.
tar -czf "$DESTINO/$NOMBRE_FINAL" -C "$ORIGEN" .

echo "BACKUP REALIZADO EXITOSAMENTE: $DESTINO/$ORIGEN"
#exit 0 para salir sin error porque la operación ha resultado exitosa.
exit 0
